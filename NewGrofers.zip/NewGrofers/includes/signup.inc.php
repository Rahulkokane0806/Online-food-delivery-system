<?php
    session_start();
    if(isset($_POST['signup'])){    
        include_once 'dbh.inc.php';
        $email=mysqli_real_escape_string($conn,$_POST['email']);
        $_SESSION['email']=$email;
        $pname=mysqli_real_escape_string($conn,$_POST['pname']);
        $address=mysqli_real_escape_string($conn,$_POST['address']);
        $pincode=mysqli_real_escape_string($conn,$_POST['pincode']);
        $mobile=mysqli_real_escape_string($conn,$_POST['mobile']);
        $pwd=mysqli_real_escape_string($conn,$_POST['password']);
        $hash = md5( rand(0,1000) );
        $sql = "SELECT * FROM users WHERE email='$email'";
        $result = mysqli_query($conn, $sql);
        $resultcheck = mysqli_num_rows($result);
        if($resultcheck > 0){
           header("location: ../signup.php?signup=emailNotAvailable");
            exit(); 
        }
        else{
            $hashpwd = password_hash($pwd,PASSWORD_DEFAULT);
            $sql = "INSERT INTO users(email,pname,address,pincode,mobile,password,verified,star,hash) VALUES ('$email','$pname','$address','$pincode','$mobile','$hashpwd','1','0','$hash');";
            mysqli_query($conn, $sql);
            $_SESSION['email']=$email;
            $_SESSION['password']=$pwd;
            $_SESSION['pname']=$pname;
            $_SESSION['hash']=$hash;
            header("location: ../userpage.php?login=success");
            exit();
        }
    }else{
        header("location: ../signup.php");
        exit();
    }
?>