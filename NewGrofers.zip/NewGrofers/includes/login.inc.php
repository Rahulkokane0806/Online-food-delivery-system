<?php
session_start();
if(isset($_POST['login'])){
    include 'dbh.inc.php';
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $pwd = mysqli_real_escape_string($conn,$_POST['password']);
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn,$sql);
    $resultcheck = mysqli_num_rows($result);
    if($resultcheck < 1){
        header("Location: ../index.php?login=false");
        exit();
    }else{
        if($row = mysqli_fetch_assoc($result)){
            //echo password_hash($pwd,PASSWORD_DEFAULT);
            $hashedpwdCheck = password_verify($pwd,$row['password']);
            if($hashedpwdCheck == false){
                header("Location: ../index.php?login=false");
                exit(); 
            }
            else {
                    $_SESSION['email'] = $row['email'];
                    header("Location: ../userpage.php?login=success");
                    exit();
                
            }
        }
    }
}else{
    header("Location: ../index.php?login=error");
    exit();
}

