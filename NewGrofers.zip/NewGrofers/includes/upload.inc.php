<?php
	session_start();
	include_once 'dbh.inc.php';
	$email = $_SESSION['email'];
	$destinationFile='';
	if(isset($_POST['upload'])){
		if(isset($_FILES['image'])){
			$price = $_POST['price'];
			$proname = $_POST['proname'];
			$image =  $_FILES['image'];
			print_r($image);
			$imagename = $_FILES['image']['name'];
			$fileExtension = explode('.', $imagename);
			$fileCheck = strtolower(end($fileExtension));
			$fileExtensionStored = array('png','jpg','jpeg');
			if(in_array($fileCheck, $fileExtensionStored)){
				$destinationFile = '../images/'.$imagename;
				move_uploaded_file($_FILES['image']['tmp_name'], $destinationFile);
				$sql = "INSERT into products (proname,image,price) values ('$proname','$destinationFile','$price')";

				mysqli_query($conn,$sql);
				header("location:../adminpage.php?Upload=true");
			}
		}
		
	}
?>