<?php
	session_start();
	$email = $_SESSION['email'];
    include_once 'dbh.inc.php';
	$count = "SELECT * from users where email = '$email'";
    $result = mysqli_query($conn,$count);
    $x = mysqli_num_rows($result);
    $row = mysqli_fetch_array($result);
    $email = $row['email'];

    if($x==0){
        header("Location: ../index.php?login=false");
        exit();
    }
    $oid=$_POST['oid'];
    $pafeRef=$_POST['pageRef'];
    $sql = "DELETE FROM orders where oid = '$oid'";
    mysqli_query($conn,$sql);
    
?>