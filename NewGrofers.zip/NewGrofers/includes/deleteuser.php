<?php
	session_start();
	$email = $_SESSION['email'];
    include_once 'dbh.inc.php';
	$count = "SELECT * from admin where email = '$email'";
    $result = mysqli_query($conn,$count);
    $x = mysqli_num_rows($result);
    $row = mysqli_fetch_array($result);
    $email = $row['email'];

    if($x==0){
        header("Location: ../adminlogin.php?login=false");
        exit();
    }
    $uid=$_POST['uid'];
    $sql = "DELETE FROM users where uid = '$uid'";
    mysqli_query($conn,$sql);
    
?>