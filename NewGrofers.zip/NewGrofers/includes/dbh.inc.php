<?php

$dbServerName="localhost";
$dbUserName="root";
$dbPassword="";
$dbName="grofers";


$conn  = mysqli_connect($dbServerName,$dbUserName,$dbPassword,$dbName);
    
    
